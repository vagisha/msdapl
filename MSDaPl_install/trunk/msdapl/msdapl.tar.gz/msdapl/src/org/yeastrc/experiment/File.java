package org.yeastrc.experiment;

public interface File {

    public abstract int getId();

    public abstract String getFileName();

}