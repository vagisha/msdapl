/**
 * 
 */
package org.yeastrc.jobqueue;

/**
 * @author Mike
 *
 */
public class MSJobUtils {

	public static final int GROUP_YATES = 0;
	public static final int GROUP_MACCOSS = 1;
	
}
