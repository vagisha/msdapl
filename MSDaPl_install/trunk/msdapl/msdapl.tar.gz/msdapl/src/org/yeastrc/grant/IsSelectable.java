package org.yeastrc.grant;

public interface IsSelectable {

	public abstract boolean isSelected();
	public abstract void setSelected(boolean selected);
}
