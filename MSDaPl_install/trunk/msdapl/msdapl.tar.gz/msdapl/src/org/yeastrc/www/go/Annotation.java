/**
 * 
 */
package org.yeastrc.www.go;

/**
 * Annotation.java
 * @author Vagisha Sharma
 * Jul 1, 2010
 * 
 */
public enum Annotation {

	NONE,
	INDIRECT,
	EXACT;
}
